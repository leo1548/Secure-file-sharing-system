
import os
import time
from flask import Flask, render_template, request, redirect, url_for, flash, session, send_from_directory
from flask_sqlalchemy import SQLAlchemy
from itsdangerous import URLSafeTimedSerializer
from flask_mail import Mail, Message
from werkzeug.utils import secure_filename
from models import db, User, File

app = Flask(__name__)
app.secret_key = "your_secret_key"
app.config["UPLOAD_FOLDER"] = "shared"
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///db.sqlite3"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# Email config
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = 'n0343377@gmail.com'
app.config['MAIL_PASSWORD'] = 'dzvs sbgx uaeg bymj'
mail = Mail(app)

serializer = URLSafeTimedSerializer(app.secret_key)
db.init_app(app)

login_attempts = {}
attempt_timestamps = {}
ATTEMPT_RESET_SECONDS = 900

@app.before_request
def create_tables():
    db.create_all()

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email")
        password = request.form.get("password")
        user = User.query.filter_by(email=email).first()
        now = time.time()

        if email in attempt_timestamps and now - attempt_timestamps[email] > ATTEMPT_RESET_SECONDS:
            login_attempts[email] = 0

        if email not in login_attempts:
            login_attempts[email] = 0

        if login_attempts[email] >= 5:
            flash("Too many failed login attempts. Please try again later.", "error")
            return render_template("login.html")

        if not user:
            flash("Email not found. Please register.", "error")
            login_attempts[email] += 1
            attempt_timestamps[email] = now
            return render_template("login.html")

        if user.password != password:
            flash("Incorrect password.", "error")
            login_attempts[email] += 1
            attempt_timestamps[email] = now
            return render_template("login.html")

        if not user.is_verified:
            flash("Please verify your email.", "error")
            return redirect(url_for("verify_notice", email=email))

        login_attempts[email] = 0
        session["user"] = user.username
        session["email"] = user.email
        session["is_admin"] = user.is_admin
        session["user_id"] = user.id
        flash("Login successful!", "success")
        return redirect(url_for("dashboard"))

    return render_template("login.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form["username"]
        email = request.form["email"]
        password = request.form["password"]
        confirm = request.form["confirm_password"]

        if password != confirm:
            flash("Passwords do not match.", "error")
            return render_template("register.html")

        if User.query.filter_by(email=email).first():
            flash("Email already registered.", "error")
        else:
            user = User(username=username, email=email, password=password, is_admin=False, is_verified=False)
            db.session.add(user)
            db.session.commit()
            send_verification_email(email)
            return redirect(url_for("verify_notice", email=email))

    return render_template("register.html")

def send_verification_email(email):
    token = serializer.dumps(email, salt='email-confirm')
    link = f"http://192.168.0.109:5000/verify/{token}"
    msg = Message("Verify Email", sender='n0343377@gmail.com', recipients=[email])
    msg.body = f"Click this link to verify: {link}"
    msg.html = render_template("email_verification.html", verify_link=link)
    mail.send(msg)

@app.route("/verify/<token>")
def verify_email(token):
    try:
        email = serializer.loads(token, salt='email-confirm', max_age=3600)
        user = User.query.filter_by(email=email).first()
        if user:
            user.is_verified = True
            db.session.commit()
            flash("Email verified! Please login.", "success")
            return redirect(url_for("login"))
    except:
        flash("Invalid or expired link.", "error")
    return redirect(url_for("register"))

@app.route("/verify-notice")
def verify_notice():
    email = request.args.get("email", "")
    return render_template("verify_notice.html", email=email)

@app.route("/resend-verification", methods=["POST"])
def resend_verification():
    email = request.form.get("email")
    user = User.query.filter_by(email=email).first()
    if user and not user.is_verified:
        send_verification_email(email)
        flash("Verification email resent.", "success")
    else:
        flash("Invalid request.", "error")
    return redirect(url_for("verify_notice", email=email))

@app.route("/forgot-password", methods=["GET", "POST"])
def forgot_password():
    if request.method == "POST":
        email = request.form.get("email")
        user = User.query.filter_by(email=email).first()
        if user:
            token = serializer.dumps(email, salt="password-reset")
            reset_url = f"http://192.168.0.109:5000/reset-password/{token}"
            msg = Message("Reset Password", sender='n0343377@gmail.com', recipients=[email])
            msg.body = f"Click to reset: {reset_url}"
            mail.send(msg)
            flash("Password reset email sent!", "success")
        else:
            flash("Email not found.", "error")
        return redirect(url_for("login"))
    return render_template("forgot_password.html")

@app.route("/reset-password/<token>", methods=["GET", "POST"])
def reset_password(token):
    try:
        email = serializer.loads(token, salt="password-reset", max_age=3600)
        user = User.query.filter_by(email=email).first()
        if not user:
            flash("Invalid user.", "error")
            return redirect(url_for("login"))

        if request.method == "POST":
            new_password = request.form.get("password")
            confirm = request.form.get("confirm_password")
            if new_password != confirm:
                flash("Passwords do not match.", "error")
                return render_template("reset_password.html")

            user.password = new_password
            db.session.commit()
            flash("Password updated!", "success")
            return redirect(url_for("login"))

        return render_template("reset_password.html")

    except:
        flash("Invalid or expired reset link.", "error")
        return redirect(url_for("forgot_password"))

@app.route("/logout")
def logout():
    session.clear()
    flash("Logged out.", "success")
    return redirect(url_for("index"))

@app.route("/dashboard")
def dashboard():
    if "user" not in session:
        flash("Please login.", "error")
        return redirect(url_for("login"))

    email = session["email"]
    user_id = session["user_id"]
    user_path = os.path.join(app.config["UPLOAD_FOLDER"], email)
    os.makedirs(user_path, exist_ok=True)
    files = File.query.filter_by(user_id=user_id).all()

    if session.get("is_admin"):
        user_data = []
        recent_files = []
        all_users = User.query.all()
        for user in all_users:
            file_count = File.query.filter_by(user_id=user.id).count()
            user_data.append({"username": user.username, "email": user.email, "file_count": file_count})
            for f in File.query.filter_by(user_id=user.id).all():
                recent_files.append((user.email, f.filename, f.size_kb))
        return render_template("admin_dashboard.html", user=session["user"], user_data=user_data, recent_files=recent_files)

    return render_template("dashboard.html", user=session["user"], email=email, files=[f.filename for f in files])

@app.route("/upload", methods=["POST"])
def upload():
    if "user" not in session:
        flash("Login required.", "error")
        return redirect(url_for("login"))

    email = session["email"]
    user_id = session["user_id"]
    file = request.files["file"]
    if file:
        filename = secure_filename(file.filename)
        path = os.path.join(app.config["UPLOAD_FOLDER"], email)
        os.makedirs(path, exist_ok=True)
        file_path = os.path.join(path, filename)
        file.save(file_path)

        size_kb = round(os.path.getsize(file_path) / 1024, 2)
        new_file = File(filename=filename, size_kb=size_kb, user_id=user_id)
        db.session.add(new_file)
        db.session.commit()

        flash("File uploaded.", "success")
    return redirect(url_for("dashboard"))

@app.route("/shared/<email>/<filename>")
def shared_file(email, filename):
    return send_from_directory(os.path.join(app.config["UPLOAD_FOLDER"], email), filename)

@app.route("/download/<filename>")
def download(filename):
    if "email" not in session:
        flash("Login required.", "error")
        return redirect(url_for("login"))

    email = session["email"]
    return send_from_directory(os.path.join(app.config["UPLOAD_FOLDER"], email), filename, as_attachment=True)

@app.route("/delete_file", methods=["POST"])
def delete_file():
    if "user" not in session:
        flash("Unauthorized access!", "error")
        return redirect(url_for("login"))

    current_email = session["email"]
    is_admin = session.get("is_admin")
    target_email = request.form.get("email") or current_email
    filename = request.form.get("filename")

    user = User.query.filter_by(email=target_email).first()
    if not user:
        flash("User not found.", "error")
        return redirect(url_for("dashboard"))

    file_entry = File.query.filter_by(filename=filename, user_id=user.id).first()
    filepath = os.path.join(app.config["UPLOAD_FOLDER"], target_email, filename)

    if os.path.exists(filepath):
        os.remove(filepath)
    if file_entry:
        db.session.delete(file_entry)
        db.session.commit()
        flash("File deleted.", "success")
    else:
        flash("File not found in DB.", "error")

    return redirect(url_for("dashboard"))

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0")
